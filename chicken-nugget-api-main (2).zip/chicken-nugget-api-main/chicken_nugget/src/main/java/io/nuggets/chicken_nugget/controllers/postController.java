package io.nuggets.chicken_nugget.controllers;

import java.util.HashMap;
import java.util.Map;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.nuggets.chicken_nugget.exceptions.CustomException;
import io.nuggets.chicken_nugget.services.PostService;
import io.nuggets.chicken_nugget.services.UserService;
import io.nuggets.chicken_nugget.entities.User;
import io.nuggets.chicken_nugget.entities.Post;
import io.nuggets.chicken_nugget.services.ImageService;

@RestController
public class postController {
    
    @Autowired
    PostService postService;

    @Autowired
    UserService userService;

    @Autowired
    ImageService imageService;

    @GetMapping("/createPost")
    public ResponseEntity<?> CreatePost(@RequestParam("file") MultipartFile file, @RequestParam String content,
            @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);

            String downloadUrl = imageService.upload(file);

            Post post = new Post(user, content, downloadUrl);

            Post responsePost = postService.createPost(post);

            Map<String, Post> response = new HashMap<>();
            response.put("post", responsePost);
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/viewPost")
    public ResponseEntity<?> ViewPost(@RequestParam String postId) {
        try {
            Post post = postService.getPostById(postId);
            Map<String, Post> response = new HashMap<>();
            response.put("post", post);
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/likePost")
    public ResponseEntity<?> LikePost(@RequestParam String postId, @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            Post post = postService.getPostById(postId);
            postService.likePost(post, user);
            Map<String, String> response = new HashMap<>();
            response.put("status", "ok");
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/unLikePost")
    public ResponseEntity<?> UnLikePost(@RequestParam String postId, @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            Post post = postService.getPostById(postId);
            postService.unlikePost(post, user);
            Map<String, String> response = new HashMap<>();
            response.put("status", "ok");
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/commentOnPost")
    public ResponseEntity<?> CommentOnPost(@RequestParam String postId, @RequestParam String authToken,
            @RequestParam String comment) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            Post post = postService.getPostById(postId);
            postService.commentOnPost(comment, post, user);
            Map<String, String> response = new HashMap<>();
            response.put("status", "ok");
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/deleteComment")
    public ResponseEntity<?> DeleteComment(@RequestParam String commentId, @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            postService.deleteComment(commentId, user);
            Map<String, String> response = new HashMap<>();
            response.put("status", "ok");
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/deletePost")
    public ResponseEntity<?> DeletePost(@RequestParam String postId, @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            Post post = postService.getPostById(postId);
            postService.deletePost(post, user);
            Map<String, String> response = new HashMap<>();
            response.put("status", "ok");
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/getPosts")
    public ResponseEntity<?> getPosts(@RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            List<Post> posts = postService.getHomePosts(user);
            Map<String, List<Post>> response = new HashMap<>();
            response.put("status", posts);
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

}
