package io.nuggets.chicken_nugget.controllers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.nuggets.chicken_nugget.exceptions.CustomException;
import io.nuggets.chicken_nugget.services.ImageService;
import io.nuggets.chicken_nugget.services.UserService;
import io.nuggets.chicken_nugget.entities.User;

@RestController
public class userController {
    
    @Autowired
    UserService userService;

    @Autowired
    ImageService imageService;

    @GetMapping("/updateProfile")
    public ResponseEntity<?> UpdateProfile(@RequestParam String bio, @RequestParam String fullName,
            @RequestParam String email, @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            userService.updateBio(user, bio);
            userService.updateEmail(user, email);
            userService.updateFullName(user, fullName);
            Map<String, User> response = new HashMap<>();
            response.put("user", user);
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/updateUserName")
    public ResponseEntity<?> ChangeUserName(@RequestParam String userName, @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            userService.updateUserName(user, userName);
            Map<String, User> response = new HashMap<>();
            response.put("user", user);
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/updatePassword")
    public ResponseEntity<?> ChangePassword(@RequestParam String currPassword, @RequestParam String newPassword,
            @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            userService.updatePassword(user, currPassword, newPassword);
            Map<String, User> response = new HashMap<>();
            response.put("user", user);
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/followUser")
    public ResponseEntity<?> FollowUser(@RequestParam String userName, @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            User followingUser = userService.getUserByUserName(userName);
            userService.followUser(followingUser, user);
            Map<String, User> response = new HashMap<>();
            response.put("user", user);
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/unFollowUser")
    public ResponseEntity<?> UnFollowUser(@RequestParam String userName, @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);
            User followingUser = userService.getUserByUserName(userName);
            userService.unFollowUser(followingUser, user);
            Map<String, User> response = new HashMap<>();
            response.put("user", user);
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

    @GetMapping("/uploadProfilePic")
    public ResponseEntity<?> UploadProfilePic(@RequestParam("file") MultipartFile file,
            @RequestParam String authToken) {
        try {
            User user = userService.getUserByAuthToken(authToken);

            String downloadUrl = imageService.upload(file);

            userService.updateProfilePic(user, downloadUrl);

            Map<String, String> response = new HashMap<>();
            response.put("url", downloadUrl);
            return ResponseEntity.ok(response);
        } catch (CustomException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(e.getMessage());
        }
    }

}
