package io.nuggets.chicken_nugget;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChickenNuggetApplicationTests {

	@Test
	void contextLoads() {
	}

}
